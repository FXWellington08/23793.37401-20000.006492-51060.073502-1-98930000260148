/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package testes;

/**
 *
 * @author alunocmc
 */
public class ProdutoDAOTeste {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       System.out.println("---Testando método listarTodos--");
       java.util.List<modelo.Produto> produtos = dao.ProdutoDAO.listarTodos();
       if (produtos != null){
           System.out.println("Conseguiu obter lista de produtos");
           for (modelo.Produto p : produtos){
                System.out.println("Id: "+p.getId()+" Nome: "+p.getNome()+" Categoria: "+ p.getCategoria());
           }
       }
       
    }
}
