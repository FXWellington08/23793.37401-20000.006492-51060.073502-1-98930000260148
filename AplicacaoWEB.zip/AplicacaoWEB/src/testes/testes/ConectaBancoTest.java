/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package testes;

import java.sql.SQLException;

/**
 *
 * @author alunocmc
 */
public class ConectaBancoTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        // TODO code application logic here
        System.out.println("--- Testando o método getConexao --");
        java.sql.Connection con = util.ConectaBanco.getConexao();
        if (con != null) {
            System.out.println("Conectado com sucesso");
            System.out.println("-- Testando o método fechaConexao --");
            util.ConectaBanco.fechaConexao(con);
        }
        else System.out.println("Erro ao conectar");
    }
    
}
