/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Cadastro;
import dao.CadastroDAO;

/**
 *
 * @author Beatr
 */

@WebServlet(name = "Controller_Cadastro", urlPatterns = {"/Controller_Cadastro"})
public class Controller_Cadastro extends HttpServlet {

    /**
     Processes requests for both HTTP <code>GET</code>
     methods.
     
     @param request servlet request
     @param response servlet response
     @throws ServletException if a servlet-specific error occurs
     @throws IOException if an I/O error occurs
     **/
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String op = request.getParameter("op");
            CadastroDAO cadao = new CadastroDAO();
            Cadastro cad = new Cadastro();
        
switch(op){
            case "novoCadastro":
            String nome = request.getParameter("nome");
            String filiacao_mae = request.getParameter("nomeMae");
            String filiacao_pai = request.getParameter("nomePai");
            String telefone = request.getParameter("telefone");
            String email = request.getParameter("email");
            String endereco = request.getParameter("endereco");
            String cpf = request.getParameter("cpf");
            int    idade = Integer.parseInt(request.getParameter ("idade"));
            String genero = request.getParameter("genero");
            String curso = request.getParameter("curso");
            double mensalidade = Double.parseDouble(request.getParameter("mensalidade"));
            int    semestre = Integer.parseInt(request.getParameter ("semestre"));

            cad.setNome(nome);
            cad.setTelefone(telefone);
            cad.setEmail(nome);
            cad.setEndereco(telefone);
            cad.setCpf(nome);
            cad.setIdade(idade);
            cad.setGenero(genero);
            cad.setFiliacao_mae(filiacao_mae);
            cad.setFiliacao_pai(filiacao_pai);
            cad.setCurso(curso);
            cad.setMensalidade(mensalidade);
            cad.setSemestre(semestre);

            String msg = "Cadastrar";
            try {
            cadao.cadastrar(cad);
            System.out.println("Cadastrado com sucesso!!");
            request.setAttribute("message", msg);
            request.getRequestDispatcher("cadastrar.jsp").forward(request, response);
            } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("Erro ClassNotFound: " + ex.getMessage());
            request.setAttribute("message", msg);
            request.getRequestDispatcher("erro.jsp").forward(request, response);
            }
            break;

   
                case "DELETAR":
                int id = Integer.parseInt(request.getParameter("txtid"));
                cad.setId(id);
                String msg = "Deletar";
                try {
                    cad.deletar(cadao);
                    List<Cadastro> lcad = cadao.listarTodos();
                    request.setAttribute("lcad", lcad);
                    request.getRequestDispatcher("resultadoconsultartodos.jsp").forward(request, response);
                } catch (ClassNotFoundException | SQLException ex) {
                    System.out.println("Erro ClassNotFound: " + ex.getMessage());
                    request.setAttribute("message", msg);
                    request.getRequestDispatcher("erro.jsp").forward(request, response);
                }
                break 
            } case "CONSULTAR BY ID": {
                int id = Integer.parseInt(request.getParameter("txtid"));
                p.setId(id);
                try {
                    p = pdao.consultarById(p);
                    request.setAttribute("p", p);
                    request.getRequestDispatcher("resultadocosultarbyid.jsp").forward(request, response);
                } catch (ClassNotFoundException | SQLException ex) {
                    System.out.println("Erro ClassNotFound: " + ex.getMessage());
                }
                break
                
            } else if (op.equals("CONSULTAR TODOS")) {
                //NÃO IMPLEMENTADO
                try {
                    List<Produto> lprod = pdao.consultarTodos();
                    request.setAttribute("lprod", lprod);
                    request.getRequestDispatcher("resultadoconsultartodos.jsp").forward(request, response);
                } catch (ClassNotFoundException | SQLException ex) {
                    System.out.println("Erro ClassNotFound: " + ex.getMessage());
                }

            } else if (op.equals("ATUALIZAR")) {
                int id = Integer.parseInt(request.getParameter("txtid"));
                p.setId(id);
                try {
                    p = pdao.consultarById(p);
                    request.setAttribute("p", p);
                    request.getRequestDispatcher("resultadocosultaratualizar.jsp").forward(request, response);
                } catch (ClassNotFoundException | SQLException ex) {
                    System.out.println("Erro ClassNotFound: " + ex.getMessage());
                }
            } else if (op.equals("EFETIVAR ATUALIZAÇÃO")) {
                int id = Integer.parseInt(request.getParameter("txtid"));
                String descricao = request.getParameter("txtdescricao");
                double preco = Double.parseDouble(request.getParameter("txtpreco"));
                p.setId(id);
                p.setDescricao(descricao);
                p.setPreco(preco);
                String msg = "Atualizar";
                try {
                    pdao.atualizar(p);
                    System.out.println("Atuaizado com sucesso!!");
                    request.setAttribute("message", msg);
                    request.getRequestDispatcher("resultado.jsp").forward(request, response);
                } catch (ClassNotFoundException | SQLException ex) {
                    System.out.println("Erro ClassNotFound: " + ex.getMessage());
                    request.setAttribute("message", msg);
                    request.getRequestDispatcher("erro.jsp").forward(request, response);
                }*/

            }

        }
    }
        

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

