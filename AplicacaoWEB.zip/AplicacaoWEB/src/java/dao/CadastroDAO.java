/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.util.List;
import modelo.Cadastro;
import util.Conexao_BD;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class CadastroDAO {

    private static final String LISTARTODOS = "SELECT * FROM cadastros";
    private static final String INSERIR = "INSERT INTO produtos (nome, telefone, email, endereco, CPF, Idade, Genero, filiacao_mae, filiacao_pai, curso, mensalidade, semestre) "
            + "                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    public static boolean inserirCadastro(Cadastro cad) {
        java.sql.Connection con = null;
        java.sql.PreparedStatement pstmt = null;
        boolean retorno = false;
        try {
            con = util.Conexao_BD.getConexao();
            pstmt = con.prepareStatement(INSERIR);
            pstmt.setString(1, cad.getNome());
            pstmt.setString(2, cad.getTelefone());
            pstmt.setString(3, cad.getEmail());
            pstmt.setString(4, cad.getEndereco());
            pstmt.setString(5, cad.getCpf());
            pstmt.setInt(6, cad.getIdade());
            pstmt.setString(7, cad.getGenero());
            pstmt.setString(8, cad.getFiliacao_mae());
            pstmt.setString(9, cad.getFiliacao_pai());
            pstmt.setString(10, cad.getCurso());
            pstmt.setDouble(11, cad.getMensalidade());
            pstmt.setInt(12, cad.getSemestre());

            pstmt.execute();
            //util.Conexao_BD.fechaConexao(con, pstmt);//
            retorno = true;
        } catch (java.sql.SQLException | ClassNotFoundException e) {
            throw new RuntimeException("Erro ao inserir: " + e.getMessage());
        }
        return retorno;
    }

    public static List<modelo.Cadastro> listarTodos() {
        java.sql.Connection con = null;
        java.sql.Statement stmt = null;
        java.sql.ResultSet rs = null;
        List<modelo.Cadastro> retorno = new java.util.ArrayList<>();
        try {
            con = util.Conexao_BD.getConexao();
            stmt = con.createStatement();
            rs = stmt.executeQuery(LISTARTODOS);
            while (rs.next()) {
                modelo.Cadastro cad = new modelo.Cadastro();
                cad.setId(rs.getInt("id"));
                cad.setNome(rs.getString("nome"));
                cad.setTelefone(rs.getString("telefone"));
                cad.setEmail(rs.getString("email"));
                cad.setEndereco(rs.getString("endereco"));
                cad.setCpf(rs.getString("cpf"));
                cad.setIdade(rs.getInt("idade"));
                cad.setGenero(rs.getString("genero"));
                cad.setFiliacao_mae(rs.getString("Filiacao_mae"));
                cad.setFiliacao_pai(rs.getString("Filiacao_pai"));
                cad.setCurso(rs.getString("curso"));
                cad.setMensalidade(rs.getDouble("mensalidade"));
                cad.setSemestre(rs.getInt("semestre"));
                retorno.add(cad);
            }
            stmt.close();
            util.Conexao_BD.fechaConexao(con);
        } catch (java.sql.SQLException | ClassNotFoundException e) {
            throw new RuntimeException("Erro ao listar: " + e.getMessage());
        }
        return retorno;
    }
    private static final String ATUALIZAR = "UPDATE produtos SET nome = ?, telefone = ?, email = ?, endereco = ?, CPF = ?, Idade = ?, Genero = ?, filiacao_mae = ?, filiacao_pai = ?, curso = ?, mensalidade = ?, semestre = ? WHERE id = ?";

    public static boolean atualizarCadastro(Cadastro cad) {
        Connection con = null;
        java.sql.PreparedStatement pstmt = null;
        boolean retorno = false;
        try {
            con = util.Conexao_BD.getConexao();
            pstmt = con.prepareStatement(ATUALIZAR);
            pstmt.setString(1, cad.getNome());
            pstmt.setString(2, cad.getTelefone());
            pstmt.setString(3, cad.getEmail());
            pstmt.setString(4, cad.getEndereco());
            pstmt.setString(5, cad.getCpf());
            pstmt.setInt(6, cad.getIdade());
            pstmt.setString(7, cad.getGenero());
            pstmt.setString(8, cad.getFiliacao_mae());
            pstmt.setString(9, cad.getFiliacao_pai());
            pstmt.setString(10, cad.getCurso());
            pstmt.setDouble(11, cad.getMensalidade());
            pstmt.setInt(12, cad.getSemestre());
            pstmt.setInt(13, cad.getId()); // ID do cadastro a ser atualizado

            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                retorno = true;
            }

            //util.Conexao_BD.fechaConexao(con, pstmt);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException("Erro ao atualizar cadastro: " + e.getMessage());
        }
        return retorno;
    }
    private static final String DELETAR = "DELETE FROM produtos WHERE id = ?";

    public static boolean deletarCadastro(int id) {
        Connection con = null;
        java.sql.PreparedStatement pstmt = null;
        boolean retorno = false;
        try {
            con = util.Conexao_BD.getConexao();
            pstmt = con.prepareStatement(DELETAR);
            pstmt.setInt(1, id);

            int linhasAfetadas = pstmt.executeUpdate();
            if (linhasAfetadas > 0) {
                retorno = true;
            }

            //util.Conexao_BD.fechaConexao(con, pstmt);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException("Erro ao deletar cadastro: " + e.getMessage());
        }
        return retorno;
    }
    private static final String BUSCAR_POR_ID = "SELECT * FROM produtos WHERE id = ?";

    public static Cadastro buscarPorId(int id) {
        Connection con = null;
        java.sql.PreparedStatement pstmt = null;
        java.sql.ResultSet rs = null;
        Cadastro cad = null;
        try {
            con = util.Conexao_BD.getConexao();
            pstmt = con.prepareStatement(BUSCAR_POR_ID);
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                cad = new Cadastro();
                cad.setId(rs.getInt("id"));
                cad.setNome(rs.getString("nome"));
                cad.setTelefone(rs.getString("telefone"));
                cad.setEmail(rs.getString("email"));
                cad.setEndereco(rs.getString("endereco"));
                cad.setCpf(rs.getString("cpf"));
                cad.setIdade(rs.getInt("idade"));
                cad.setGenero(rs.getString("genero"));
                cad.setFiliacao_mae(rs.getString("filiacao_mae"));
                cad.setFiliacao_pai(rs.getString("filiacao_pai"));
                cad.setCurso(rs.getString("curso"));
                cad.setMensalidade(rs.getDouble("mensalidade"));
                cad.setSemestre(rs.getInt("semestre"));
            }

            //util.Conexao_BD.fechaConexao(con, pstmt, rs);
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException("Erro ao buscar cadastro por ID: " + e.getMessage());
        }
        return cad;
    }

    public void cadastrar(Cadastro cad) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
