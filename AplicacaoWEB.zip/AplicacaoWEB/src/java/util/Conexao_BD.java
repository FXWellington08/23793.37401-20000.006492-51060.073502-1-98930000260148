
package util;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;

public class Conexao_BD {
    
    private static final String USUARIO = "postgres";
    private static final String SENHA   = "umc@2024";
    private static final String BANCO   = "sistema_cadastro";
    private static final String DRIVER  = "org.postgresql.Driver";
    private static final String URL     = "jdbc:postgresql://localhost:5432/";
   
    // Método para obter a conexão com o banco
    public static Connection getConexao() throws ClassNotFoundException, SQLException {
        try {
            Class.forName(DRIVER);
            return java.sql.DriverManager.getConnection(URL + BANCO, USUARIO, SENHA);
        } catch (ClassNotFoundException e) {
            throw new ClassNotFoundException("Driver não encontrado: " + e.getMessage());
        } catch (SQLException e) {
            throw new SQLException("Erro ao conectar: " + e.getMessage());
        }
    }

    // Método para fechar a conexão, PreparedStatement e ResultSet, caso necessário
    public static void fechaConexao(Connection con) {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
                System.out.println("Conexão fechada com sucesso.");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao fechar conexão: " + e.getMessage());
        }
    }
}
