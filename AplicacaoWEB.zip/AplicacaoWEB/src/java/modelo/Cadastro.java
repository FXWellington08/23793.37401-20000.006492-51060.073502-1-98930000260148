/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import dao.CadastroDAO;

public class Cadastro {
    private int     id;
    private String  nome;
    private String  telefone;
    private String  email;
    private int     idade;
    private String  endereco;
    private String  cpf;

    public Cadastro() {
    }
    private String  genero;
    private String  filiacao_mae;
    private String  filiacao_pai;
    private String  curso;
    private double  mensalidade;
    private int     semestre;

    public Cadastro(int id, String nome, String telefone, String email, int idade, String endereco, String cpf, String genero, String filiacao_mae, String filiacao_pai, String curso, double mensalidade, int semestre) {
        this.id             = id;
        this.nome           = nome;
        this.telefone       = telefone;
        this.email          = email;
        this.idade          = idade;
        this.endereco       = endereco;
        this.cpf            = cpf;
        this.genero         = genero;
        this.filiacao_mae   = filiacao_mae;
        this.filiacao_pai   = filiacao_pai;
        this.curso          = curso;
        this.mensalidade    = mensalidade;
        this.semestre       = semestre;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getFiliacao_mae() {
        return filiacao_mae;
    }

    public void setFiliacao_mae(String filiacao_mae) {
        this.filiacao_mae = filiacao_mae;
    }

    public String getFiliacao_pai() {
        return filiacao_pai;
    }

    public void setFiliacao_pai(String filiacao_pai) {
        this.filiacao_pai = filiacao_pai;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public double getMensalidade() {
        return mensalidade;
    }

    public void setMensalidade(double mensalidade) {
        this.mensalidade = mensalidade;
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public void deletar(CadastroDAO cadao) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
       
}
