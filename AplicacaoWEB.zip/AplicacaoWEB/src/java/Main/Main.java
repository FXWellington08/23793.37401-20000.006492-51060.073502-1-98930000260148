/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;
 
import modelo.Cadastro;
import dao.CadastroDAO;
import java.util.List;

        
public class Main {

    public static void main(String[] args) {
        // Testando a inserção de um novo cadastro
        Cadastro novoCadastro = new Cadastro(0, "Maria Silva", "123456789", "maria@email.com", 22,
                "Rua A, 123", "123.456.789-00", "Feminino", "Ana Silva", "João Silva", 
                "Engenharia", 1500.0, 2);
        
        boolean inserido = CadastroDAO.inserirCadastro(novoCadastro);
        if (inserido) {
            System.out.println("Cadastro inserido com sucesso!");
        } else {
            System.out.println("Erro ao inserir cadastro.");
        }
        
        // Listando todos os cadastros
        List<Cadastro> listaCadastros = CadastroDAO.listarTodos();
        System.out.println("\nLista de cadastros:");
        for (Cadastro cadastro : listaCadastros) {
            System.out.println(cadastro);
        }
        
        // Atualizando um cadastro
        if (!listaCadastros.isEmpty()) {
            Cadastro cadastroParaAtualizar = listaCadastros.get(0);
            cadastroParaAtualizar.setNome("Maria Silva Atualizada");
            boolean atualizado = CadastroDAO.atualizarCadastro(cadastroParaAtualizar);
            if (atualizado) {
                System.out.println("\nCadastro atualizado com sucesso!");
            } else {
                System.out.println("\nErro ao atualizar cadastro.");
            }
        }

        // Buscando um cadastro por ID
        Cadastro cadastroBuscado = CadastroDAO.buscarPorId(1); // Substitua o ID conforme necessário
        if (cadastroBuscado != null) {
            System.out.println("\nCadastro encontrado: " + cadastroBuscado);
        } else {
            System.out.println("\nCadastro não encontrado.");
        }
        
        // Deletando um cadastro
        boolean deletado = CadastroDAO.deletarCadastro(1); // Substitua o ID conforme necessário
        if (deletado) {
            System.out.println("\nCadastro deletado com sucesso!");
        } else {
            System.out.println("\nErro ao deletar cadastro.");
        }
    }
}

